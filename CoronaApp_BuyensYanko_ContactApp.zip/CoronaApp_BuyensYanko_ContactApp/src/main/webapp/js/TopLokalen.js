window.onload = getNewHighestRoom;

var tabel = document.getElementById("topLokalenTabel");


function getNewHighestRoom () {
    $.ajax({
        type: "GET",
        url: "Controller?command=TopLokalen",
        dataType: "json",
        success: function (json) {
            clearRooms(tabel);
            $(json).each(function (index,lokaal) {

                let newRow = tabel.insertRow();
                let lokalen = document.createTextNode(lokaal);
                let lokalenCell = newRow.insertCell();
                lokalenCell.appendChild(lokalen);
            })
            setTimeout(getNewHighestRoom, 10000);
        },
        error: function () {
            alert("An error occurred while getting the rooms ...");
        }
    });
}


function clearRooms(rooms) {
    while (rooms.childNodes[1] != null) {
        rooms.removeChild(rooms.lastChild);
    }
}