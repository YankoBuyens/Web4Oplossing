window.onload = startNotifyContact;
let quotebutton = document.getElementById('notifyContactButton');

quotebutton.onclick = notifycontact;

var webSocket;

function startNotifyContact() {
    webSocket = new WebSocket("ws://localhost:8080/echo"); //ws://localhost:8080/Contact_Tracing_war/echo

    webSocket.onopen = function (event) {
    }
    webSocket.onmessage = function (event) {
        writeResponse(event.data)
    }
    webSocket.onclose = function (event) {
    }
}

function writeResponse(text){
    var notifyTable= document.getElementById("notifyContactTable");
    var textLijst = text.split("||");
    let newRow = notifyTable.insertRow();
    let name = document.createTextNode(textLijst[0])
    let date = document.createTextNode(textLijst[1]);
    let nameCell = newRow.insertCell();
    nameCell.appendChild(name);
    let dateCell = newRow.insertCell();
    dateCell.appendChild(date);

}

function notifycontact(){
    var text = document.getElementById("nametext").value;
    text  += "||"+ document.getElementById("datetext").value;
    webSocket.send(text);
}