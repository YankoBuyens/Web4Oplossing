$(function (){
   /* var $login = $('#loginForm');
    var $logout = $('#logoutForm');

    $('#loginFriends').hide();

    $login.on('submit',function(){
        $('#loginFriends').show();
    });

    $logout.on('submit',function(){
        $('#loginFriends').hide();
    });*/
});
