let quotebutton = document.getElementById('addPersonButton');
quotebutton.onclick = searchPersons;


function searchPersons (){
    let dateText = document.getElementById("datetext");
    let roomText = document.getElementById("roomtext");
    let input = "Controller?command=SearchPersons&date="+encodeURIComponent(dateText.value)+"&room="+encodeURIComponent(roomText.value);
    fetch(input).then(response => response.json()).then(data => showsearchPersons(data));
}


function showsearchPersons(persons) {
    let personDiv = document.getElementById("searchtabel");
    clearPersons(personDiv);
    for (let person in persons) {
        let newRow = personDiv.insertRow(); //Voegt een tr toe aan de tabel
        let firstName = document.createTextNode(persons[person].firstName);
        let lastName = document.createTextNode(persons[person].lastName);
        let email = document.createTextNode(persons[person].email);
        let gsm = document.createTextNode(persons[person].gsm);

        let firstNameCell = newRow.insertCell();
        firstNameCell.appendChild(firstName);
        let lastNameCell = newRow.insertCell();
        lastNameCell.appendChild(lastName);
        let emailCell = newRow.insertCell();
        emailCell.appendChild(email);
        let gsmCell = newRow.insertCell();
        gsmCell.appendChild(gsm)
    }
}

function clearPersons(personsearchDiv) {
    while (personsearchDiv.childNodes[1] != null) {
        personsearchDiv.removeChild(personsearchDiv.lastChild);
    }
}

