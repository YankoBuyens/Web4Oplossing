$(function (){
    var $addFriendForm = $('#addFriendButton');
    var tabel = document.getElementById("addFriendTable");

    $addFriendForm.on('click',function(){
        $email = document.getElementById("emailtext").value;
        $.post("Controller?command=AddFriend", {friendEmail:$email}, function(data) {
            clearPersons(tabel);
            for (let person in data) {
                let newRow = tabel.insertRow();

                let firstName = document.createTextNode(data[person].firstName);
                let lastName = document.createTextNode(data[person].lastName);
                let firstNameCell = newRow.insertCell();
                firstNameCell.appendChild(firstName);
                let lastNameCell = newRow.insertCell();
                lastNameCell.appendChild(lastName);
                if(data[person].covidPositief){
                    firstNameCell.style.color = "red";
                    lastNameCell.style.color = "red";
                }
                else {
                    firstNameCell.style.color = "green";
                    lastNameCell.style.color = "green";
                }
            }
        });
    });

});


function clearPersons(tabel) {
    while (tabel.childNodes[1] != null) {
        tabel.removeChild(tabel.lastChild);
    }
}