
let quotebutton = document.getElementById('addPersonButton');
quotebutton.onclick = addPerson;

let newPersonRequest = new XMLHttpRequest();


function addPerson () {
    let firstNameText = document.getElementById("firstNametext");
    let lastNameText = document.getElementById("lastNametext");
    let dateText = document.getElementById("datetext");
    let roomText = document.getElementById("roomtext");
    let emailText = document.getElementById("emailtext");
    let gsmText = document.getElementById("gsmtext");
    let covidText = document.getElementById("covidtext");
    let fout = false;

    if(firstNameText.value === ""){
        firstNameText.style.border = "2px solid red";
        fout = true;
    }
    if(lastNameText.value === ""){
        lastNameText.style.border = "2px solid red";
        fout = true;
    }
    if(dateText.value === ""){
        dateText.style.border = "2px solid red";
        fout = true;
    }
    if(roomText.value === ""){
        roomText.style.border = "2px solid red";
        fout = true;
    }
    if(emailText.value === ""){
        emailText.style.border = "2px solid red";
        fout = true;
    }
    if(gsmText.value === ""){
        gsmText.style.border = "2px solid red";
        fout = true;
    }



    let information =     "firstName=" + encodeURIComponent(firstNameText.value)
        + "&lastName=" + encodeURIComponent(lastNameText.value)
        + "&date=" + encodeURIComponent(dateText.value)
        + "&room=" + encodeURIComponent(roomText.value)
        + "&email=" + encodeURIComponent(emailText.value)
        + "&gsm=" + encodeURIComponent(gsmText.value)
        + "&covidPositief=" + encodeURIComponent(covidText.value);

    newPersonRequest.open("POST", "Controller?command=AddPerson", true);
    newPersonRequest.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

    if(fout === false) {
        firstNameText.value = "";
        firstNameText.style.border = "";
        lastNameText.value = "";
        lastNameText.style.border = "";
        dateText.value = "";
        dateText.style.border = "";
        roomText.value = "";
        roomText.style.border = "";
        emailText.value = "";
        emailText.style.border = "";
        gsmText.value = "";
        gsmText.style.border = "";
    }
    newPersonRequest.send(information);
}
