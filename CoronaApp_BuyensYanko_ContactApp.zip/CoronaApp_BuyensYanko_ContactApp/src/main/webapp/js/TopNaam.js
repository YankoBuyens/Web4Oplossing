window.onload = getTopNaam;

var tabel = document.getElementById("topNaam");


function getTopNaam () {
    $.ajax({
        type: "GET",
        url: "Controller?command=TopNaam",
        dataType: "json",
        success: function (json) {
            clearRooms(tabel);

                let newRow = tabel.insertRow();
                let namen = document.createTextNode(json);
                let namenCell = newRow.insertCell();
                namenCell.appendChild(namen);

            setTimeout(getTopNaam, 10000);
        },
        error: function () {
            alert("An error occurred while getting the top naam ...");
        }
    });
}


function clearRooms(naams) {
    while (naams.childNodes[1] != null) {
        naams.removeChild(naams.lastChild);
    }
}