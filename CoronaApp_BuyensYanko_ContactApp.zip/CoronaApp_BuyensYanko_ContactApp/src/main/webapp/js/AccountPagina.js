function start() {
    getTopNaam();
    getNewAccountPersons();
}



let getPersonsRequest = new XMLHttpRequest();


let personDiv = document.getElementById("tabel");
var tabel = document.getElementById("topNaam");



function getNewAccountPersons () {
    getPersonsRequest.open("GET", "Controller?command=GetAllAccountPersons", true);

    getPersonsRequest.onreadystatechange = showAccountPersons;
    getPersonsRequest.send(null);
}
function showAccountPersons () {
    if (getPersonsRequest.readyState === 4) {
        if(getPersonsRequest.status === 200) {
            let jsonpersons = JSON.parse(getPersonsRequest.responseText)
            clearAccountPersons();


            for (let person in jsonpersons) {
                let newRow = personDiv.insertRow();

                let firstName = document.createTextNode(jsonpersons[person].firstName);
                let lastName = document.createTextNode(jsonpersons[person].lastName);
                let email = document.createTextNode(jsonpersons[person].email);

                let firstNameCell = newRow.insertCell();
                firstNameCell.appendChild(firstName);
                let lastNamCell = newRow.insertCell();
                lastNamCell.appendChild(lastName);
                let emailCell = newRow.insertCell();
                emailCell.appendChild(email);
            }
            setInterval(getNewAccountPersons, 5000);
        }
    }
}

function clearAccountPersons() {
    while (personDiv.childNodes[1] != null) {
        personDiv.removeChild(personDiv.lastChild);
    }
}




function getTopNaam () {
    $.ajax({
        type: "GET",
        url: "Controller?command=TopNaam",
        dataType: "json",
        success: function (json) {
            clearRooms(tabel);

            let newRow = tabel.insertRow();
            let namen = document.createTextNode(json);
            let namenCell = newRow.insertCell();
            namenCell.appendChild(namen);

            setTimeout(getTopNaam, 10000);
        },
        error: function () {
            alert("An error occurred while getting the top naam ...");
        }
    });
}


function clearRooms(naams) {
    while (naams.childNodes[1] != null) {
        naams.removeChild(naams.lastChild);
    }
}


window.onload = start;