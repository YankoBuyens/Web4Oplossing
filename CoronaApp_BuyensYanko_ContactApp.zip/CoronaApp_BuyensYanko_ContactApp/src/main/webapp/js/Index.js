function start() {
    getNewHighestRoom();
    getNewPersons();
    kijkNaarP();
}

let getPersonsRequest = new XMLHttpRequest();


let personDiv = document.getElementById("tabel");
var tabel = document.getElementById("topLokalenTabel");


function getNewPersons () {
    getPersonsRequest.open("GET", "Controller?command=GetAllLast20Persons", true);

    getPersonsRequest.onreadystatechange = showLast20Persons;
    getPersonsRequest.send(null);
}
function showLast20Persons () {
    if (getPersonsRequest.readyState === 4) {
        if(getPersonsRequest.status === 200) {

            let jsonpersons = JSON.parse(getPersonsRequest.responseText)
            clearPersons();


            for (let person in jsonpersons) {
                let newRow = personDiv.insertRow(); //Voegt een tr toe aan de tabel

                let firstName = document.createTextNode(jsonpersons[person].firstName);
                let lastName = document.createTextNode(jsonpersons[person].lastName);
                let date = document.createTextNode(jsonpersons[person].date);
                let room = document.createTextNode(jsonpersons[person].room);
                let email = document.createTextNode(jsonpersons[person].email);
                let gsm = document.createTextNode(jsonpersons[person].gsm);

                let firstNameCell = newRow.insertCell();
                firstNameCell.appendChild(firstName);
                let lastNameCell = newRow.insertCell();
                lastNameCell.appendChild(lastName);
                let dateCell = newRow.insertCell();
                dateCell.appendChild(date);
                let roomCell = newRow.insertCell();
                roomCell.appendChild(room);
                let emailCell = newRow.insertCell();
                emailCell.appendChild(email);
                let gsmCell = newRow.insertCell();
                gsmCell.appendChild(gsm);

            }
            setInterval(getNewPersons, 5000);
        }
    }
}

function clearPersons() {
    while (personDiv.childNodes[1] != null) {
        personDiv.removeChild(personDiv.lastChild);
    }
}


function getNewHighestRoom () {
    $.ajax({
        type: "GET",
        url: "Controller?command=TopLokalen",
        dataType: "json",
        success: function (json) {
            clearRooms(tabel);
            $(json).each(function (index,lokaal) {

                let newRow = tabel.insertRow();
                let lokalen = document.createTextNode(lokaal);
                let lokalenCell = newRow.insertCell();
                lokalenCell.appendChild(lokalen);
            })
            setTimeout(getNewHighestRoom, 5000);
        },
        error: function () {
            alert("An error occurred while getting the rooms ...");
        }
    });
}


function clearRooms(rooms) {
    while (rooms.childNodes[1] != null) {
        rooms.removeChild(rooms.lastChild);
    }
}

function kijkNaarP(){
    var FriendZichtBaarText = document.getElementById("FriendZichtBaarText");
    if(FriendZichtBaarText == null){
        $('#loginFriends').hide();
    }
    else{
        $('#loginFriends').show();
    }

}

window.onload = start;

