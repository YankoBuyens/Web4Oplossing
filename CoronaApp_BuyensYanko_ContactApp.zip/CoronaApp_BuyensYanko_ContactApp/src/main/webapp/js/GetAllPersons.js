window.onload = getNewPersons;



let getPersonsRequest = new XMLHttpRequest();


let personDiv = document.getElementById("tabel");


function getNewPersons () {
    getPersonsRequest.open("GET", "Controller?command=GetAllPersons", true);

    getPersonsRequest.onreadystatechange = showPersons;
    getPersonsRequest.send(null);
}
function showPersons () {
    if (getPersonsRequest.readyState === 4) {
        if(getPersonsRequest.status === 200) {
            let jsonpersons = JSON.parse(getPersonsRequest.responseText)
            clearPersons();


            for (let person in jsonpersons) {
                let newRow = personDiv.insertRow();

                let firstName = document.createTextNode(jsonpersons[person].firstName);
                let lastName = document.createTextNode(jsonpersons[person].lastName);
                let date = document.createTextNode(jsonpersons[person].date);
                let room = document.createTextNode(jsonpersons[person].room);
                let email = document.createTextNode(jsonpersons[person].email);
                let gsm = document.createTextNode(jsonpersons[person].gsm);

                let firstNameCell = newRow.insertCell();
                firstNameCell.appendChild(firstName);
                let lastNameCell = newRow.insertCell();
                lastNameCell.appendChild(lastName);
                let dateCell = newRow.insertCell();
                dateCell.appendChild(date);
                let roomCell = newRow.insertCell();
                roomCell.appendChild(room);
                let emailCell = newRow.insertCell();
                emailCell.appendChild(email);
                let gsmCell = newRow.insertCell();
                gsmCell.appendChild(gsm);

            }
            setInterval(getNewPersons, 5000);
        }
    }
}

function clearPersons() {
    while (personDiv.childNodes[1] != null) {
        personDiv.removeChild(personDiv.lastChild);
    }
}