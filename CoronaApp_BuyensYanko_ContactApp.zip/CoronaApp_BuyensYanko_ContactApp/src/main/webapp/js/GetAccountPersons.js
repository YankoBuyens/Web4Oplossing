window.onload = getNewAccountPersons;



let getPersonsRequest = new XMLHttpRequest();


let personDiv = document.getElementById("tabel");


function getNewAccountPersons () {
    getPersonsRequest.open("GET", "Controller?command=GetAllAccountPersons", true);

    getPersonsRequest.onreadystatechange = showAccountPersons;
    getPersonsRequest.send(null);
}
function showAccountPersons () {
    if (getPersonsRequest.readyState === 4) {
        if(getPersonsRequest.status === 200) {
            let jsonpersons = JSON.parse(getPersonsRequest.responseText)
            clearAccountPersons();


            for (let person in jsonpersons) {
                let newRow = personDiv.insertRow();

                let firstName = document.createTextNode(jsonpersons[person].firstName);


                let firstNameCell = newRow.insertCell();
                firstNameCell.appendChild(firstName);
            }
            setInterval(getNewAccountPersons, 5000);
        }
    }
}

function clearAccountPersons() {
    while (personDiv.childNodes[1] != null) {
        personDiv.removeChild(personDiv.lastChild);
    }
}
