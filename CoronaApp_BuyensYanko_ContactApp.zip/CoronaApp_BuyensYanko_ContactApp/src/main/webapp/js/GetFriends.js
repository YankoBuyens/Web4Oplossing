window.onload = getFriends;

var tabel = document.getElementById("addFriendTable");


function getFriends () {
    $.ajax({
        type: "GET",
        url: "Controller?command=GetFriends",
        dataType: "json",
        success: function (json) {
            clearFriends(tabel);
            $(json).each(function (index,friends) {
                let newRow = tabel.insertRow();
                let firstName = document.createTextNode(friends.firstName);
                let lastName = document.createTextNode(friends.lastName);
                let firstNameCell = newRow.insertCell();
                firstNameCell.appendChild(firstName);
                let lastNameCell = newRow.insertCell();
                lastNameCell.appendChild(lastName);
                if(friends.covidPositief){
                    firstNameCell.style.color = "red";
                    lastNameCell.style.color = "red";
                }
                else {
                    firstNameCell.style.color = "green";
                    lastNameCell.style.color = "green";
                }
            })
            setTimeout(getFriends, 10000);
        },
        error: function () {
            alert("An error occurred while getting the friends ...");
        }
    });
}


function clearFriends(friends) {
    while (friends.childNodes[1] != null) {
        friends.removeChild(friends.lastChild);
    }
}