package ui.controller;

import domain.model.AccountPerson;
import domain.model.ContactService;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Login extends Synchroonhandler{
    @Override
    public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String destination = "index.jsp";
        List<String> errors = new ArrayList<String>();

        String email = request.getParameter("email");
        if (email == null || email.isEmpty()) {
            errors.add("No email given");
        }

        String password = request.getParameter("password");
        if (password == null || password.isEmpty()) {
            errors.add("No password given");
        }

        if (errors.size() == 0) {
            ContactService contactService = super.getService();
            AccountPerson accountPerson = contactService.getAuthenticatedUser(email, password);
            if (accountPerson != null) {
                createSession(accountPerson, request, response);
            } else {
                errors.add("No valid email/password");
            }
        }

        if (errors.size() > 0) {
            request.setAttribute("errors", errors);
        }

        return destination;
    }

    private void createSession(AccountPerson person, HttpServletRequest request,
                               HttpServletResponse response) {
        HttpSession session = request.getSession();
        session.setAttribute("accountPerson", person);
    }
}

