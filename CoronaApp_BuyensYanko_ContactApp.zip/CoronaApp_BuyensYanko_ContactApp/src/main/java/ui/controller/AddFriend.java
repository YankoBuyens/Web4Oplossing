package ui.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import domain.model.AccountPerson;
import domain.model.ContactService;
import domain.model.DomainException;
import domain.model.Person;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

public class AddFriend extends Asynchroonhandler{
    @Override
    public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       String email = request.getParameter("friendEmail");
       ContactService contactService = super.getService();



        try {
            HttpSession session = request.getSession();
            AccountPerson accountPerson = (AccountPerson) session.getAttribute("accountPerson");
            Person persons = contactService.getPerson(email);
            contactService.addFriends(accountPerson,persons);
            AccountPerson accountPerson1= contactService.geefAccountPersonMetZelfdeEmail(persons);
            Person person1 = contactService.geefPersonMetZelfdeEmail(accountPerson);
            contactService.addFriends(accountPerson1,person1);
            String friendJSON = this.toJSON(contactService.getFriendsPersons(accountPerson));
            return friendJSON;
        }catch (Exception e){
            throw new IllegalArgumentException(e.getMessage());
        }
    }

    private String toJSON (List<Person> person) throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.writeValueAsString(person);
    }

}
