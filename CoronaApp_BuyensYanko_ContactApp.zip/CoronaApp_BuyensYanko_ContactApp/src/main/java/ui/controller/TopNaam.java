package ui.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import domain.model.AccountPerson;
import domain.model.Person;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.*;

public class TopNaam extends Asynchroonhandler{

    @Override
    public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<AccountPerson> persons = super.getService().getAccountPersons();
        Map<String, Integer> map = new HashMap<>();
        for (AccountPerson person : persons) {
            Integer val = map.get(person.getFirstName());
            map.put(person.getFirstName(), val == null ? 1 : val + 1);
        }

        List<Map.Entry<String, Integer>> list = new ArrayList<>(map.entrySet());
        list.sort(Map.Entry.comparingByValue());
        Collections.reverse(list);

        Map<String, Integer> result = new LinkedHashMap<>();
        for (Map.Entry<String, Integer> entry : list) {
            result.put(entry.getKey(), entry.getValue());
        }

        List<String> lijst = new ArrayList<>(result.keySet());
        String JsonLijst;
        JsonLijst = lijst.get(0);


        String topNaamJSON = this.toJSON(JsonLijst);
        return topNaamJSON;
    }

    private String toJSON ( String topNaam) throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.writeValueAsString(topNaam);
    }
}
