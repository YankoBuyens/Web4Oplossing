package ui.controller;

import domain.model.AccountPerson;
import domain.model.Person;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Enumeration;

public class AddAccountPerson extends Synchroonhandler{
    @Override
    public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String firstName = (String)request.getParameter("firstName");
        String lastName = (String)request.getParameter("lastName");
        String email = (String)request.getParameter("email");
        String password = (String)request.getParameter("password");
        String date = (String)request.getParameter("date");
        String room = (String)request.getParameter("room");
        String gsm = (String)request.getParameter("gsm");
        String covidPositiefString = (String)request.getParameter("covidPositief");
        boolean covidPositief = Boolean.valueOf(covidPositiefString);

        AccountPerson accountPerson = new AccountPerson(firstName,lastName,email, password);
        super.getService().addAccountPerson(accountPerson);
        Person person = new Person(firstName,lastName,date,room,email,gsm,covidPositief);
        super.getService().addPerson(person);
        createSession(accountPerson, request, response);


        return "index.jsp";
    }

    private void createSession(AccountPerson person, HttpServletRequest request,
                               HttpServletResponse response) {
        HttpSession session = request.getSession();
        session.setAttribute("accountPerson", person);
    }
}
