package ui.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import domain.model.Person;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.*;

public class TopLokalen extends Asynchroonhandler{

    @Override
    public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Person> persons = super.getService().getPersons();
        Map<Integer, Integer> map = new HashMap<>();
        for (Person person : persons) {
            Integer val = map.get(Integer.parseInt(person.getRoom()));
            map.put(Integer.parseInt(person.getRoom()), val == null ? 1 : val + 1);
        }

        List<Map.Entry<Integer, Integer>> list = new ArrayList<>(map.entrySet());
        list.sort(Map.Entry.comparingByValue());
        Collections.reverse(list);

        Map<Integer, Integer> result = new LinkedHashMap<>();
        for (Map.Entry<Integer, Integer> entry : list) {
            result.put(entry.getKey(), entry.getValue());
        }

        List<Integer> lijst = new ArrayList<>(result.keySet());
        List<Integer> JsonLijst = new ArrayList<>();
        JsonLijst.add(lijst.get(0));
        JsonLijst.add(lijst.get(1));
        JsonLijst.add(lijst.get(2));

        String roomsJSON = this.toJSON(JsonLijst);
        return roomsJSON;
        }

        private String toJSON ( List<Integer> rooms) throws JsonProcessingException {
            ObjectMapper mapper = new ObjectMapper();
            return mapper.writeValueAsString(rooms);
        }
}
