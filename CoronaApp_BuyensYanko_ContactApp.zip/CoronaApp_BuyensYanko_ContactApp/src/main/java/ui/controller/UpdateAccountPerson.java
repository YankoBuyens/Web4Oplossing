package ui.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import domain.model.AccountPerson;
import domain.model.Person;

import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.DataInput;
import java.io.IOException;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class UpdateAccountPerson extends Synchroonhandler{
    @Override
    public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        BufferedReader reader = request.getReader();
        ObjectMapper mapper = new ObjectMapper();
        JsonNode rootNode = mapper.readTree(reader);
        List<AccountPerson> accountPersons = super.getService().getAccountPersons();
        List<Person> personList = super.getService().getPersons();

        for(int i = 0 ; i != rootNode.size(); i++){
            String firstName = rootNode.get(i).get("firstName").toPrettyString().replace("\"","");
            String lastName = rootNode.get(i).get("lastName").toPrettyString().replace("\"","");
            String email = rootNode.get(i).get("email").toPrettyString().replace("\"","");
            String password = rootNode.get(i).get("password").toPrettyString().replace("\"","");

            accountPersons.get(i).setFirstName(firstName);
            accountPersons.get(i).setLastName(lastName);
            accountPersons.get(i).setEmail(email);
            accountPersons.get(i).setPassword(password);
            personList.get(i).setEmail(email);
            personList.get(i).setFirstName(firstName);
            personList.get(i).setLastName(lastName);


        }


        return "";
    }



}
