package ui.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import domain.model.ContactService;
import domain.model.Person;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Enumeration;

@WebServlet("/Controller")
public class Controller extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private ControllerFactory controllerFactory = new ControllerFactory();
    private ContactService service;

    public Controller() {
        super();
        service = new ContactService();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }

    private void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("command");
        if (action == null || action.isEmpty())
            action = "Home";
        RequestHandler handler = controllerFactory.getController(action,service);
        String json = "";
        try {
            json =  handler.handleRequest(request, response);
            response.setHeader("Access-Control-Allow-Origin", "*");
        } catch (NotAuthorizedException e) {
            request.setAttribute("notAuthorized", "You have insufficient rights to have a look at the requested page.");
            controllerFactory.getController("Home",service).handleRequest(request,response);
        }


        if(handler instanceof Synchroonhandler) {
            RequestDispatcher view = request.getRequestDispatcher(json);
            view.forward(request, response);
        }

        if(handler instanceof Asynchroonhandler) {
            response.setContentType("application/json");
            response.getWriter().write(json);
        }
    }
}

