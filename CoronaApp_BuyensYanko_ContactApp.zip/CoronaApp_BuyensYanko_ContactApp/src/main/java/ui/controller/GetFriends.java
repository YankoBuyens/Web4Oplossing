package ui.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import domain.model.AccountPerson;
import domain.model.ContactService;
import domain.model.Person;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

public class GetFriends extends Asynchroonhandler{
    @Override
    public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ContactService contactService = super.getService();

        try {
            HttpSession session = request.getSession();
            AccountPerson accountPerson = (AccountPerson) session.getAttribute("accountPerson");
            String friendJSON = this.toJSON(contactService.getFriendsPersons(accountPerson));
            return friendJSON;
        }catch (Exception e){
            throw new IllegalArgumentException(e.getMessage());
        }
    }

    private String toJSON (List<Person> person) throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.writeValueAsString(person);
    }

}
