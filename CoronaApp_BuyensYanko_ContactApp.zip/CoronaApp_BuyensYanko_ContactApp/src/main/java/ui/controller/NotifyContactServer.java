package ui.controller;

import java.io.IOException;
import java.util.*;

import javax.websocket.OnClose;
import javax.websocket.OnMessage;
import javax.websocket.Session;
import javax.websocket.OnOpen;
import javax.websocket.server.ServerEndpoint;

@ServerEndpoint("/echo")
public class NotifyContactServer {


    private static final Set<Session> sessions = Collections.synchronizedSet(new HashSet<Session>());
    private static final List<String> notifyLijst = Collections.synchronizedList(new ArrayList<String>());

    @OnOpen
    public void onOpen(Session session){
        sessions.add(session);
        for(String text : notifyLijst){
            try {
                session.getBasicRemote().sendText(text);
            }catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }

    @OnMessage
    public void onMessage(String message, Session session){
        sendMessageToAll(message);
        notifyLijst.add(message);
    }

    @OnClose
    public void onClose(Session session){
        sessions.remove(session);
    }

    private void sendMessageToAll(String message){
        for(Session s : sessions) {
            try {
                s.getBasicRemote().sendText(message);
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }
}
