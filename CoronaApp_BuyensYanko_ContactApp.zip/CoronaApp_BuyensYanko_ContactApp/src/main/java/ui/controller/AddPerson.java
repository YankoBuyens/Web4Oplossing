package ui.controller;

import domain.model.Person;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class AddPerson extends Asynchroonhandler{

    @Override
    public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String firstName = (String)request.getParameter("firstName");
        String lastName = (String)request.getParameter("lastName");
        String date = (String)request.getParameter("date");
        String room = (String)request.getParameter("room");
        String email = (String)request.getParameter("email");
        String gsm = (String)request.getParameter("gsm");
        String covidPositiefString = (String)request.getParameter("covidPositief");
        boolean covidPositief = Boolean.valueOf(covidPositiefString);
        Person person = new Person(firstName,lastName,date,room,email,gsm,covidPositief);
        super.getService().addPerson(person);

        return "";
    }
}
