package domain.model;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AccountPerson {
    private String firstName,lastName,email,password;
    private ArrayList<Person> friends = new ArrayList<>();

    public AccountPerson(String firstName,String lastName,String email, String password){
        super();
        setFirstName(firstName);
        setLastName(lastName);
        setEmail(email);
        setPassword(password);
    }

    public String getFirstName() {
        return firstName;
    }
    public void setFirstName(String firstName) {
        if(firstName.isEmpty() || firstName == null){
            throw new DomainException("No firstName given");
        }
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        if(lastName.isEmpty() || lastName == null){
            throw new DomainException("No lastName given");
        }
        this.lastName = lastName;
    }

    public String getLastName(){
        return lastName;
    }

    public void setEmail(String email) {
        if(email.isEmpty() || email == null){
            throw new DomainException("No email given");
        }
        String USERID_PATTERN =
                "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
                        + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
        Pattern p = Pattern.compile(USERID_PATTERN);
        Matcher m = p.matcher(email);
        if (!m.matches()) {
            throw new DomainException("Email not valid");
        }
        this.email = email;
    }

    public String getEmail(){
        return email;
    }

    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        if(password.isEmpty() || password == null){
            throw new DomainException("No password given");
        }
        this.password = password;
    }

    public boolean isCorrectPassword(String password) {
        if (password.isEmpty()) {
            throw new IllegalArgumentException("No password given");
        }
        return getPassword().equals(password);
    }

    public ArrayList<Person> getFriends(){
        return friends;
    }

    public void addFriends(Person person){
        if(person == null){
            throw new DomainException("Persoon mag niet leeg zijn");
        }
        for(Person person1 : friends){
            if(person1.equals(person)){
                throw new DomainException("Persoon is al toegevoegd");
            }
        }
        friends.add(person);
    }


}
