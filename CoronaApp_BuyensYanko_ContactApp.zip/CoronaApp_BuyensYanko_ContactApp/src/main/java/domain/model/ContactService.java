package domain.model;

import domain.db.AccountPersonRepository;
import domain.db.PersonRepository;

import java.util.List;

public class ContactService {

    PersonRepository personRepository  ;
    AccountPersonRepository accountPersonRepository;

    public ContactService(){
        personRepository = new PersonRepository();
        accountPersonRepository = new AccountPersonRepository();
    }
    public List<Person> getPersons(){
        return personRepository.getPersons();
    }

    public List<Person> getLast20Persons() {return personRepository.getLast20Persons();}

    public void addPerson (Person person) { personRepository.addPerson(person);}

    public List<Person> searchPersons(String room, String date){ return personRepository.searchPersons(room,date);}

    public List<AccountPerson> getAccountPersons(){
        return accountPersonRepository.getAccountPersons();
    }

    public void addAccountPerson (AccountPerson accountPerson) {   accountPersonRepository.addAccountPerson(accountPerson);}

    public AccountPerson getAuthenticatedUser(String email, String password) { return accountPersonRepository.getAuthenticatedUser(email, password); }

    public List<Person> getFriendsPersons(AccountPerson accountPerson){
        return accountPersonRepository.getFriends(accountPerson);
    }

    public void addFriends (AccountPerson accountPerson, Person person) {   accountPersonRepository.addFriend(accountPerson,person);}

    public Person getPerson(String email){return personRepository.getPerson(email);}

    public AccountPerson geefAccountPersonMetZelfdeEmail(Person person){
        return  accountPersonRepository.getAccountPerson(person.getEmail());
    }

    public Person geefPersonMetZelfdeEmail(AccountPerson person){
        return personRepository.getPerson(person.getEmail());
    }
}
