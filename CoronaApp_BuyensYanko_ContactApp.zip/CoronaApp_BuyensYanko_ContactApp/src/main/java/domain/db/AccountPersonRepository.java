package domain.db;

import domain.model.AccountPerson;
import domain.model.Person;

import java.util.ArrayList;
import java.util.List;

public class AccountPersonRepository {
    private List<AccountPerson> accountpersons = new ArrayList<AccountPerson>();

    public AccountPersonRepository() {
        super();
        AccountPerson person = new AccountPerson("Aaron","Bibber","AB@gmail.com","t");
        accountpersons.add(person);
        AccountPerson person1 = new AccountPerson("Bil","cibber","BC@gmail.com","t");
        accountpersons.add(person1);
        AccountPerson person2 = new AccountPerson("Chilwell","Dibber","CD@gmail.com","t");
        accountpersons.add(person2);
        AccountPerson person3 = new AccountPerson("Derin","Oibber","DO@gmail.com","t");
        accountpersons.add(person3);
        AccountPerson person4 = new AccountPerson("Eilen","Eibber","EE@gmail.com","t");
        accountpersons.add(person4);
        AccountPerson person5 = new AccountPerson("Folter","Fibber","FF@gmail.com","t");
        accountpersons.add(person5);
        AccountPerson person6 = new AccountPerson("Grieper","Gibber","GG@gmail.com","t");
        accountpersons.add(person6);
        AccountPerson person7 = new AccountPerson("Huipert","Hibber","HH@gmail.com","t");
        accountpersons.add(person7);
        AccountPerson person8 = new AccountPerson("Ilen","Ibber","II@gmail.com","t");
        accountpersons.add(person8);
        AccountPerson person9 = new AccountPerson("Juilen","Jibber","JJ@gmail.com","t");
        accountpersons.add(person9);


    }

    public void addAccountPerson (AccountPerson person) {
        for(AccountPerson accountPerson : accountpersons){
            if(person.getEmail().equals(accountPerson.getEmail())){
                throw new IllegalArgumentException("Email is al in gebruik");
            }
        }
        accountpersons.add(person);
    }

    public List<AccountPerson> getAccountPersons(){
        return accountpersons;
    }

    public AccountPerson getAccountPerson(String email){
        if(email == null){
            throw new IllegalArgumentException("No id given");
        }
        for(AccountPerson person : accountpersons ){
            if(person.getEmail().equals(email)){
                return person;
            }
        }
        throw new IllegalArgumentException("Er is geen persoon die zo heet");
    }



    public AccountPerson getAuthenticatedUser(String email, String password) {
        AccountPerson person = getAccountPerson(email);

        if (person != null && person.isCorrectPassword(password)) {
            return person;
        }
        else {
            return null;
        }
    }

    public ArrayList<Person> getFriends(AccountPerson accountPerson){
        return accountPerson.getFriends();
    }

    public void addFriend(AccountPerson accountPerson,Person person){
        try {
            accountPerson.addFriends(person);
        }catch (Exception e){
            throw new IllegalArgumentException(e.getMessage());
        }
    }

}
