package domain.db;

import domain.model.DomainException;
import domain.model.Person;

import java.util.ArrayList;
import java.util.List;

public class PersonRepository {

    private List<Person> persons = new ArrayList<Person>();

    public PersonRepository() {
        super();
        Person person = new Person("Rik","Blob","17-02-2000","17","AB@gmail.com","0469130232",true);
        persons.add(person);
        Person person1 = new Person("Zelt","Alter","18-02-2000","18","BC@gmail.com","0462130232",false);
        persons.add(person1);
        Person person2 = new Person("Zork","Blist","17-02-2001","19","CD@gmail.com","0469131002",false);
        persons.add(person2);
        Person person3 = new Person("Meir","Werlt","17-02-2010","20","DO@gmail.com","0425130518",true);
        persons.add(person3);
        Person person4 = new Person("Welt","Mope","17-02-2023","20","EE@gmail.com","0434120212",false);
        persons.add(person4);
        Person person5 = new Person("Aagje","Meter","3-02-2023","20","FF@gmail.com","0434120212",true);
        persons.add(person5);
        Person person6 = new Person("Bob","Beter","4-02-2023","25","GG@gmail.com","0434120212",false);
        persons.add(person6);
        Person person7 = new Person("Chris","Ceter","5-02-2023","24","HH@gmail.com","0455110232",false);
        persons.add(person7);
        Person person8 = new Person("Dirk","Deter","6-02-2023","25","II@gmail.com","0455110232",true);
        persons.add(person8);
        Person person9 = new Person("Erik","Eeter","7-02-2023","26","JJ@gmail.com","0455110232",true);
        persons.add(person9);
   /*     Person person10 = new Person("Fert","Feter","8-02-2023","27","Fert@gmail.com","0455110232");
        persons.add(person10);
        Person person11 = new Person("Geerhart","Geter","9-02-2023","28","Geerhart@gmail.com","0455110232");
        persons.add(person11);
        Person person12 = new Person("Hart","Heter","10-02-2023","29","Hart@gmail.com","0455110232");
        persons.add(person12);
        Person person13 = new Person("Inne","Ieter","9-02-2023","30","Inne@gmail.com","0455110232");
        persons.add(person13);
        Person person14 = new Person("Jan","Jeter","9-02-2023","1","Jan@gmail.com","0455110232");
        persons.add(person14);
        Person person15 = new Person("Karel","Keter","9-02-2023","4","Karel@gmail.com","0455110232");
        persons.add(person15);
        Person person16 = new Person("Lennert","Leter","9-02-2023","3","Lennert@gmail.com","0455110232");
        persons.add(person16);
        Person person17 = new Person("Merel","Meter","9-02-2023","33","Merel@gmail.com","0455110232");
        persons.add(person17);
        Person person18 = new Person("Nazer","Neter","9-02-2023","35","Nazer@gmail.com","0455110232");
        persons.add(person18);
        Person person19 = new Person("Ona","Oeter","9-02-2023","2","Ona@gmail.com","0455110232");
        persons.add(person19);
        Person person20 = new Person("Pieter","Peter","9-02-2023","6","Pieter@gmail.com","0455110232");
        persons.add(person20);
        Person person21 = new Person("Quinten","Qeter","9-02-2023","7","Quinten@gmail.com","0455110232");
        persons.add(person21);
        Person person22 = new Person("Rentel","Reter","9-02-2023","8","Rentel@gmail.com","0455110232");
        persons.add(person22);
        Person person23 = new Person("Scherpen","Durpe","17-02-2023","36","Schepen@gmail.com","0434120212");
        persons.add(person23);
        */
    }

    public void addPerson (Person person) {
        persons.add(person);
    }

    public List<Person> getPersons(){
        return persons;
    }

    public List<Person> getLast20Persons(){
        int listlengte = persons.size() ;
        int lengt = persons.size() - 21;
        List<Person> nieuweLijst = new ArrayList<Person>();
        if(listlengte > 20){
            for(int i = listlengte - 1; i > lengt; --i){
                nieuweLijst.add(persons.get(i));
            }
            return  nieuweLijst;
        }
        else{
            return persons;
        }
    }

    public List<Person> searchPersons(String room, String date){
        List<Person> searchLijst = new ArrayList<>();
        for(Person person : persons){
            if(person.getRoom().equals(room) && person.getDate().equals(date)){
                searchLijst.add(person);
            }
        }
        return searchLijst;
    }

    public Person getPerson(String email){

        for(Person person : persons){
            if(person.getEmail().equals(email)){
                return person;
            }
        }
        throw new DomainException("Er bestaat geen persoon met die email");
    }
}
