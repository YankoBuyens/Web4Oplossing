export class AccountPerson{
  firstName: string;
  lastName: string;
  email: string;
  password: string;
}
