import {Component, OnInit} from '@angular/core';
import {AccountPerson} from './accountPerson';
import {AccountPersonService} from './accountPerson.service';
import {timer} from 'rxjs';



@Component({
  selector: 'app-person',
  template: `
    <h2>Hallo</h2>
    <table>
      <ng-container *ngFor= "let accountPerson of accountPersons">
        <tr (click)="onSelect(accountPerson)">
          <td>{{accountPerson.firstName}}</td>
          <td>{{accountPerson.lastName}}</td>
        </tr>
      </ng-container>
    </table>
    <br>
    <br>
    <br>
    <br>
    <div *ngIf="selectedAccountPerson">
      <div>
        <label>firstname: </label>
        <input [(ngModel)]="selectedAccountPerson.firstName" placeholder="firtsName"/>
        <br>
        <label>lastname: </label>
        <input [(ngModel)]="selectedAccountPerson.lastName" placeholder="lastName"/>
        <br>
        <label>email: </label>
        <input [(ngModel)]="selectedAccountPerson.email" placeholder="email"/>
        <br>
        <label>password: </label>
        <input [(ngModel)]="selectedAccountPerson.password" placeholder="password"/>
        <br>
        <button (click)="onUpdate()">Update Data</button>
      </div>
    </div>
  `
})

export class AppComponent  implements OnInit{
  title = 'Hello';
  accountPersons: AccountPerson[];
  selectedAccountPerson: AccountPerson;

  // dependency injection
  constructor(private accountPersonService: AccountPersonService) {
  }

  // Call subscribe() to start listening for updates
  getAccountPersons(): void {
    // polling
 /*   timer(0, 2500)
      .subscribe(() => {*/
        this.accountPersonService.getAccountPersons()
          .subscribe(data => this.accountPersons = data);
     // });
  }

  onSelect(accountPerson: AccountPerson): void {
    this.selectedAccountPerson = accountPerson;
  }

  onUpdate(): void {
    this.accountPersonService.updateAccountPersons(this.accountPersons).subscribe(
      data => {
        console.log(this.accountPersons);
      },
      error => {
        console.log(JSON.stringify(error.json()));
      }
    );
  }

  ngOnInit(): void {
    this.getAccountPersons();
  }
}
