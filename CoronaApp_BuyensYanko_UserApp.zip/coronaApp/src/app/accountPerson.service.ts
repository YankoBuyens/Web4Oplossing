
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import {AccountPerson} from './accountPerson';
import { HttpHeaders } from '@angular/common/http';

import {Observable} from 'rxjs';
import {ajax} from 'rxjs/ajax';


@Injectable()
export class AccountPersonService {

  private accountPersonUrl = 'http://localhost:8080/Controller?command=GetAllAccountPersons';

  private accountPersonToevoegenurl = 'http://localhost:8080/Controller?command=UpdateAccountPerson';
  constructor(private http: HttpClient) {
  }
   getAccountPersons(): Observable<AccountPerson[]> {
    return this.http.get<AccountPerson[]>(this.accountPersonUrl);
  }
  updateAccountPersons(accountPerson: AccountPerson[]): Observable<JSON> {
    console.log(JSON.stringify(accountPerson));
    return this.http.post<JSON>(this.accountPersonToevoegenurl, JSON.stringify(accountPerson));
  }
}
